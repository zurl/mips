# MIPS Assembler Design Suite

Author: Zhang Chengyi (zurl@live.com)


## Deployment

```sh
npm install
npm install -g typescript
tsc
npm start
```